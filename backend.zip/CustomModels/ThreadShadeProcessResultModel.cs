﻿namespace BrandixAutomation.Labdip.API.Models
{
    public class ThreadShadeProcessResultModel : LabdipChartModel
    {
    }
}
