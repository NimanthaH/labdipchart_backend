﻿namespace BrandixAutomation.Labdip.API.Models
{
    public partial class Cell
    {
        public int ColIndex { get; set; }
        public int RowIndex { get; set; }
        public string ColValue { get; set; } = string.Empty;
    }
}
