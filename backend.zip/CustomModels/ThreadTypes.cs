﻿namespace BrandixAutomation.Labdip.API.Models
{
    public class PlacementNames
    {
        public int Id { get; set; }
        public string InitialPlacementName { get; set; }
        public int SubId { get; set; }
        public string PlacementName { get; set; }
    }
}
