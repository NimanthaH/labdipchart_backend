﻿namespace BrandixAutomation.Labdip.API.Models
{
    public class ThreadTypes
    {
        public int Id { get; set; }
        public string ThreadType { get; set; }
        public string Supplier { get; set; }
        public string TicketNo { get; set; }
    }
}
