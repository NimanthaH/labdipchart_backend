﻿namespace BrandixAutomation.Labdip.API.Models
{
    public class Customers
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Variation { get; set; }
    }
}
