﻿namespace BrandixAutomation.Labdip.API.Models
{
    public class LabdipChartSubModel
    {
        public int Index { get; set; }
        public string ColumnAttribute { get; set; }
        public string ColumnHeader { get; set; }
        public string ValueAttribute { get; set; }
        public string ColumnValue { get; set; }
    }
}
