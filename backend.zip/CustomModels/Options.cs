﻿namespace BrandixAutomation.Labdip.API.Models
{
    public class Options
    {
        public string OptionId { get; set; }
        public string OptionName { get; set; }
        public string Type { get; set; }
    }
}
