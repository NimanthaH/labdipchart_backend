﻿namespace BrandixAutomation.Labdip.API.DTOs
{
    public enum ResponseStatus
    {
        NotSet,
        OK,
        Invalid,
        Error
    }
}
