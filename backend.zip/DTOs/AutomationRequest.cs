﻿namespace BrandixAutomation.Labdip.API.DTOs
{
    public class AutomationRequest<T> : BaseRequest<T>
    {
    }
}
